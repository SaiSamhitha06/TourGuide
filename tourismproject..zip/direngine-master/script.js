function redirectToAnotherPage() {
    // Redirect to another page
    window.location.href = 'thank.html';
}
